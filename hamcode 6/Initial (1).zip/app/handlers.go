package app

import (
	"net/http"
)

var Repo *Repository

func CreateAttendanceHandler(w http.ResponseWriter, r *http.Request) {
	// TODO Implement
}

func GetAllAttendanceHandler(w http.ResponseWriter, r *http.Request) {
	// TODO Implement
}

func GetAttendanceHandler(w http.ResponseWriter, r *http.Request) {
	// TODO Implement
}

func UpdateAttendanceHandler(w http.ResponseWriter, r *http.Request) {
	// TODO Implement
}

func DeleteAttendanceHandler(w http.ResponseWriter, r *http.Request) {
	// TODO Implement
}

func DeleteOneDayAttendanceHandler(w http.ResponseWriter, r *http.Request) {
	// TODO Implement
}

func GetGirinofReportHandler(w http.ResponseWriter, r *http.Request) {
	// TODO Implement
}

func GetMonthlyReportHandler(w http.ResponseWriter, r *http.Request) {
	// TODO Implement
}

func GetSalaryHandler(w http.ResponseWriter, r *http.Request) {
	// TODO Implement
}

func CreateProgrammerHandler(w http.ResponseWriter, r *http.Request) {
	// TODO Implement
}
