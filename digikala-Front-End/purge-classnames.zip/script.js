function purgeClassNames(...classNames){
  // TODO write your code here
  return classNames;
}

document.getElementById('input').onkeyup = function(){
  document.getElementById('output').innerHTML = purgeClassNames(...this.value.trim().split(/\s+/));
};