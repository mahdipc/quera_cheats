package main

import (
	"fmt"
)

func HelloCodeCup(n int) string {
}

func main() {
	str := HelloCodeCup(6)
	fmt.Println(str)
}
