package main

import "younesious/hamcode/app"

func main() {
	app.StartServer()
}
